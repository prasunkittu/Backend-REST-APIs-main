const express = require("express");
const app = express();

app.use(express.json());

app.use("/api/users", require("./routes/userRoute"));
app.use("/api/products", require("./routes/productRoute"));
app.use("/api/orders", require("./routes/orderRoute"));
app.use("/api/cart", require("./routes/cartRoute"));

app.get("/", (req, res) => {
  res.send("Backend REST API is running successfully ");
});

app.listen(3000, () => {
  console.log("Server running on port 3000");
});